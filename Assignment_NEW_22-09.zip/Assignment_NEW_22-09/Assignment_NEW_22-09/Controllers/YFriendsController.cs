﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Assignment_NEW_22_09.Models;

namespace Assignment_NEW_22_09.Controllers
{
    public class YFriendsController : Controller
    {
        private AdventureWorks2017Entities db = new AdventureWorks2017Entities();

        // GET: YFriends
        public ActionResult Index()
        {
            return View(db.YFriends.ToList());
        }

        // GET: YFriends/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            YFriend yFriend = db.YFriends.Find(id);
            if (yFriend == null)
            {
                return HttpNotFound();
            }
            return View(yFriend);
        }

        // GET: YFriends/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: YFriends/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "FId,FName,LName,Place")] YFriend yFriend)
        {
            if (ModelState.IsValid)
            {
                db.YFriends.Add(yFriend);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(yFriend);
        }

        // GET: YFriends/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            YFriend yFriend = db.YFriends.Find(id);
            if (yFriend == null)
            {
                return HttpNotFound();
            }
            return View(yFriend);
        }

        // POST: YFriends/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "FId,FName,LName,Place")] YFriend yFriend)
        {
            if (ModelState.IsValid)
            {
                db.Entry(yFriend).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(yFriend);
        }

        // GET: YFriends/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            YFriend yFriend = db.YFriends.Find(id);
            if (yFriend == null)
            {
                return HttpNotFound();
            }
            return View(yFriend);
        }

        // POST: YFriends/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            YFriend yFriend = db.YFriends.Find(id);
            db.YFriends.Remove(yFriend);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
